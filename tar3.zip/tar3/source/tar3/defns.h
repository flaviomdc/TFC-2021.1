
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <math.h> 
#include <time.h>
#include <malloc.h>


#define	 false	0 
#define	 true	1 
#define	 Nil	0    
#define	 Unknown	-999		/* must be int */
#define	 Invalid	-998		/* must be int */

#define Max(a,b) ((a)>(b)? a:b)
#define Min(a,b) ((a)<(b)? a:b)
#define Round(x) ((int) (x+0.5))

#define ForEach(v,f,l)  for(v=f;v<=l;++v)



